#pragma once
#include <windows.h>
#include "MyForm2.h"
#include "MyForm.h"


namespace ProjectClr {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for MyForm1
	/// </summary>
	public ref class MyForm1 : public System::Windows::Forms::Form
	{
	public:
		MyForm1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm1()
		{
			if (components)
			{
				delete components;
			}
		}







	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ id_txt;


	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::TextBox^ aid_txt;
	private: System::Windows::Forms::TextBox^ item_txt;
	private: System::Windows::Forms::TextBox^ inbound_txt;






	private: System::Windows::Forms::Button^ button1;
	protected:

	protected:

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->id_txt = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->aid_txt = (gcnew System::Windows::Forms::TextBox());
			this->item_txt = (gcnew System::Windows::Forms::TextBox());
			this->inbound_txt = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// button8
			// 
			this->button8->Location = System::Drawing::Point(430, 378);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(75, 23);
			this->button8->TabIndex = 7;
			this->button8->Text = L"signout";
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &MyForm1::button8_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(94, 122);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(62, 13);
			this->label1->TabIndex = 8;
			this->label1->Text = L"CustomerID";
			this->label1->Click += gcnew System::EventHandler(this, &MyForm1::label1_Click);
			// 
			// id_txt
			// 
			this->id_txt->Location = System::Drawing::Point(256, 122);
			this->id_txt->Name = L"id_txt";
			this->id_txt->Size = System::Drawing::Size(100, 20);
			this->id_txt->TabIndex = 9;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(94, 178);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(55, 13);
			this->label2->TabIndex = 10;
			this->label2->Text = L"StorageID";
			this->label2->Click += gcnew System::EventHandler(this, &MyForm1::label2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(94, 223);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(38, 13);
			this->label3->TabIndex = 11;
			this->label3->Text = L"ItemID";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(94, 270);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(57, 13);
			this->label4->TabIndex = 12;
			this->label4->Text = L"InboundID";
			// 
			// aid_txt
			// 
			this->aid_txt->Location = System::Drawing::Point(256, 175);
			this->aid_txt->Name = L"aid_txt";
			this->aid_txt->Size = System::Drawing::Size(100, 20);
			this->aid_txt->TabIndex = 13;
			// 
			// item_txt
			// 
			this->item_txt->Location = System::Drawing::Point(256, 216);
			this->item_txt->Name = L"item_txt";
			this->item_txt->Size = System::Drawing::Size(100, 20);
			this->item_txt->TabIndex = 14;
			// 
			// inbound_txt
			// 
			this->inbound_txt->Location = System::Drawing::Point(256, 270);
			this->inbound_txt->Name = L"inbound_txt";
			this->inbound_txt->Size = System::Drawing::Size(100, 20);
			this->inbound_txt->TabIndex = 15;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(430, 197);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 16;
			this->button1->Text = L"Delete";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm1::button1_Click_1);
			// 
			// MyForm1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(539, 437);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->inbound_txt);
			this->Controls->Add(this->item_txt);
			this->Controls->Add(this->aid_txt);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->id_txt);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button8);
			this->Name = L"MyForm1";
			this->Text = L"MyForm1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button8_Click(System::Object^ sender, System::EventArgs^ e) {
		Application::Exit();
	}
private: System::Void button1_Click_1(System::Object^ sender, System::EventArgs^ e) {
	String^ constring = L"datasource=wms-database-3.cnuuwsy8dtiz.us-west-1.rds.amazonaws.com;port=3306;username=root;password=samuraiedge";
	//String^ constring = L"datasource=127.0.0.1;port=3306;username=root;password=onetwo22";
	MySqlConnection^ conDataBase = gcnew MySqlConnection(constring);
	
	//MySqlCommand^ cmdDataBase = gcnew MySqlCommand("delete from wms.employee where id = '"+this->id_txt->Text+"' ;", conDataBase); //'"this->Name_txt->Text+"','"+this->Surname_txt->Text+"','"+this->Age_txt->Text+
	MySqlCommand^ cmdDataBase = gcnew MySqlCommand("delete from legacywms.customer where customerID = '" + this->id_txt->Text + "'; delete from legacywms.storage where storageLocationID = '" + this->aid_txt->Text + "'; delete from legacywms.item where itemId = '" + this->item_txt->Text + "'; delete from legacywms.inbound where itemId = '" + this->inbound_txt->Text + "';", conDataBase);
	//MySqlCommand^ cmdDataBase = gcnew MySqlCommand("delete from wms.admin where adminID = '" + this->aid_txt->Text + "'; delete from wms.employee where id = '"+this->id_txt->Text+"'; delete from wms.item where itemId = '"+this->item_txt->Text+"';", conDataBase);
	//MySqlCommand^ cmdDataBase = gcnew MySqlCommand("insert into wms.employee (id, name, surname, age) values ('"+this->id_txt->Text+"','"+this->Name_txt->Text+"','" + this->Surname_txt->Text + "','" + this->Age_txt->Text + "') ;", conDataBase); //'"this->Name_txt->Text+"','"+this->Surname_txt->Text+"','"+this->Age_txt->Text+
	MySqlDataReader^ myReader;
	//MySqlDataReader^ myReader1; // delete 

	try {
		conDataBase->Open();
		myReader = cmdDataBase->ExecuteReader();
		//myReader1 = cmdDataBase1->ExecuteReader();
		
		while (myReader->Read()) {
			
		}
		

	}
	catch (Exception ^ ex) {
		MessageBox::Show(ex->Message);
	}
}
private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label2_Click(System::Object^ sender, System::EventArgs^ e) {
}
};
}
