#pragma once
#include <windows.h>
#include "MyForm2.h"
#include "MyForm.h"


namespace ProjectClr {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::TextBox^ aName_txt;
	private: System::Windows::Forms::TextBox^ aMail_txt;


	private: System::Windows::Forms::Label^ username_lbl;
	private: System::Windows::Forms::Label^ password_lbl;
	private: System::Windows::Forms::Label^ label1;
	protected:

	protected:


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->aName_txt = (gcnew System::Windows::Forms::TextBox());
			this->aMail_txt = (gcnew System::Windows::Forms::TextBox());
			this->username_lbl = (gcnew System::Windows::Forms::Label());
			this->password_lbl = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(351, 202);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 0;
			this->button1->Text = L"Login";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// aName_txt
			// 
			this->aName_txt->Location = System::Drawing::Point(326, 121);
			this->aName_txt->Name = L"aName_txt";
			this->aName_txt->Size = System::Drawing::Size(100, 20);
			this->aName_txt->TabIndex = 1;
			// 
			// aMail_txt
			// 
			this->aMail_txt->Location = System::Drawing::Point(326, 163);
			this->aMail_txt->Name = L"aMail_txt";
			this->aMail_txt->Size = System::Drawing::Size(100, 20);
			this->aMail_txt->TabIndex = 2;
			// 
			// username_lbl
			// 
			this->username_lbl->AutoSize = true;
			this->username_lbl->Location = System::Drawing::Point(147, 121);
			this->username_lbl->Name = L"username_lbl";
			this->username_lbl->Size = System::Drawing::Size(55, 13);
			this->username_lbl->TabIndex = 3;
			this->username_lbl->Text = L"Username";
			// 
			// password_lbl
			// 
			this->password_lbl->AutoSize = true;
			this->password_lbl->Location = System::Drawing::Point(150, 169);
			this->password_lbl->Name = L"password_lbl";
			this->password_lbl->Size = System::Drawing::Size(53, 13);
			this->password_lbl->TabIndex = 4;
			this->password_lbl->Text = L"Password";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(21, 33);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(69, 13);
			this->label1->TabIndex = 5;
			this->label1->Text = L"WMS Sign in";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(499, 376);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->password_lbl);
			this->Controls->Add(this->username_lbl);
			this->Controls->Add(this->aMail_txt);
			this->Controls->Add(this->aName_txt);
			this->Controls->Add(this->button1);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {

		String^ constring = L"datasource=wms-database-3.cnuuwsy8dtiz.us-west-1.rds.amazonaws.com;port=3306;username=root;password=samuraiedge";
		
		MySqlConnection^ conDataBase = gcnew MySqlConnection(constring);
		MySqlCommand^ cmdDataBase = gcnew MySqlCommand("select * from legacywms.admin where aName='" + this->aName_txt->Text + "' and aMail ='" + this->aMail_txt->Text + "' ;", conDataBase);
		//MySqlCommand^ cmdDataBase = gcnew MySqlCommand("select * from wms.admin where aName='" +this->aName_txt->Text + "' and aMail ='" + this->aMail_txt->Text + "' ;", conDataBase);
		//MySqlCommand^ cmdDataBase = gcnew MySqlCommand("select * from wms.employee where username='"+this-> username_txt->Text+"' and password ='"+this->password_txt->Text+"' ;",conDataBase);
		MySqlDataReader^ myReader;
	
		try {
			conDataBase->Open();
			myReader = cmdDataBase->ExecuteReader();
			int count = 0;
			while (myReader->Read()) {
				count = count + 1;
			}
			if (count == 1) {
				MessageBox::Show("Username and password is correct");
				this->Hide();
				MyForm1^ f1 = gcnew MyForm1();
				f1->ShowDialog();
			}
			else if (count > 1) {
				MessageBox::Show("Duplicate Username and password ...Access denied");
			}
			else
				MessageBox::Show("Username or password is not correct");

		}
		catch (Exception ^ ex) {
			MessageBox::Show(ex->Message);
		}
	}
	private: System::Void Msg_text_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	};
}
