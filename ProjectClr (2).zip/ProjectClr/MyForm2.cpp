/*
#include "MyForm2.h"
#include "MyForm.h"

using namespace System;
using namespace System::Windows::Forms;
[STAThreadAttribute]	//i don't even remember what this does..


int main()
{
	Windows::Forms::Application::EnableVisualStyles();	//makes the buttons and stuff look less ugly...
	Windows::Forms::Application::Run(gcnew ProjectClr::MyForm());
	return 0;
}
*/


#include "MyForm.h"
using namespace System;

using namespace System::Windows::Forms;

[STAThreadAttribute]

void Main(array<String^>^ args)

{

	Application::EnableVisualStyles(); Application::SetCompatibleTextRenderingDefault(false); ProjectClr::MyForm form; Application::Run(% form);

}
